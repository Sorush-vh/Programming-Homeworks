import java.util.Scanner;
import view.*;
public class Main {
    
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        RegisterMenu.run(scanner);
    }
}
