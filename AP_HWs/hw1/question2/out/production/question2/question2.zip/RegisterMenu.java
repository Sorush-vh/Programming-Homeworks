import java.util.Scanner;
import java.util.regex.Matcher;

public class RegisterMenu extends Menu{

    private static String MenuName;
    private static boolean keepGoing=true;

    static{
        setMenuName("Register/Login Menu");
    }


    public static void run(Scanner scanner){

        String registerRegex="register username (?<username>.+) password (?<password>.+)";
        String loginRegex="login username (?<username>.+) password (?<password>.+)";
    
        String input,output="";
        while (keepGoing) {

            input=scanner.nextLine();

            Matcher registerMatcher=Commands.giveTheMatcherStraightUp(input, registerRegex);
            Matcher loginMatcher=Commands.giveTheMatcherStraightUp(input, loginRegex);

            if(registerMatcher.matches()){
                String username=registerMatcher.group("username");
                String password=registerMatcher.group("password");
                output=register(username, password);
            }
            else if(loginMatcher.matches()){
                String username=loginMatcher.group("username");
                String password=loginMatcher.group("password");
                output=login(username, password);
            }
            else if(input.equals(showCurrentMenuFormat)){
                output="Register/Login Menu\n";
            }
            else if(input.equals("Exit"))
             return;
            
            else output="Invalid command!\n";

                
            System.out.print(output);
            output="";
        }
        keepGoing=true;
        MainMenu.run(scanner);
    }



    private static String register(String username, String password){

        if(!isUsernameValid(username)) return "Incorrect format for username!\n";

        if(!isPasswordFormatValid(password)) return "Incorrect format for password!\n";

        if(Server.getUserByUsername(username) != null) return "Username already exists!\n";

        User tempUser=new User(username, password);
        setUserStartingTroops(tempUser);

        return "User "+username+" created successfully!\n";
    }

    private static String login(String username, String password){
        if(!isUsernameValid(username)) return "Incorrect format for username!\n";

        if(!isPasswordFormatValid(password)) return "Incorrect format for password!\n";

        User targetUser=Server.getUserByUsername(username);
        if(targetUser==null) return "Username doesn't exist!\n";

        if(!targetUser.getPassword().equals(password)) return "Password is incorrect!\n";

        Server.setCurrentUser(targetUser);
        keepGoing=false;

        return "User "+username+" logged in!\n";
    }

    private static void setMenuName(String name){
        MenuName=name;
    }

    private static String getMenuName(){
        return MenuName;
    }

    private static void setUserStartingTroops(User user){
        BattleCard barbarian=Troops.makeBarbarian();
        Spells fireball=Spells.makeFireball();
        user.getAcquiredCards().add(fireball);
        user.getAcquiredCards().add(barbarian);

        user.getDeck().add(fireball);
        user.getDeck().add(barbarian);
    }
}
