import java.util.Scanner;
import java.util.regex.Matcher;

public class ProfileMenu extends Menu {
    
    private static String MenuName;
    private static boolean keepGoing=true;
    //ToDo: show menu and back
    static{
        ProfileMenu.setMenuName("Profile Menu");
    }

    public static void run(Scanner scanner){
        
        String changePasswordRegex="change password old password (?<oldPassword>.+) new password (?<newPassword>.+)";
        String removeFromDeckRegex="remove from battle deck (?<cardName>.+)";
        String addToDeckRegex="add to battle deck (?<cardName>.+)";

        String input,output="";

        while (keepGoing) {
            input=scanner.nextLine();

            Matcher changePasswordMatcher=Commands.giveTheMatcherStraightUp(input, changePasswordRegex);
            Matcher removeFromDeckMatcher=Commands.giveTheMatcherStraightUp(input, removeFromDeckRegex);
            Matcher addToDeckMatcher=Commands.giveTheMatcherStraightUp(input, addToDeckRegex);

            if(input.equals("back")){
                output="Entered main menu!\n";
                keepGoing=false;
            }
            else if(input.equals(showCurrentMenuFormat)){
                output="Profile Menu\n";
            }
            else if(input.equals("Info")){
                output=tellCurrentUsersInfo();
            }
            else if(input.equals("show battle deck")){
                output=showDeck();
            }
            else if(changePasswordMatcher.matches()){
                String oldPassword=changePasswordMatcher.group("oldPassword");
                String newPassword=changePasswordMatcher.group("newPassword");
                output=changePassword(oldPassword, newPassword);
            }
            else if(removeFromDeckMatcher.matches()){
                String cardName=removeFromDeckMatcher.group("cardName");
                output=removeFromDeck(cardName);
            }
            else if(addToDeckMatcher.matches()){
                String cardName=addToDeckMatcher.group("cardName");
                output=addToDeck(cardName);
            }
            else output="Invalid command!\n";

            System.out.print(output);
            output="";
        }
        keepGoing=true;
        MainMenu.run(scanner);
    }


    private static String changePassword(String oldPassword, String newPassword){
        if(!Server.getCurrentUser().getPassword().equals(oldPassword)) return "Incorrect password!\n";

        if(!isPasswordFormatValid(newPassword)) return "Incorrect format for new password!\n";

        Server.getCurrentUser().setPassword(newPassword);
        return "Password changed successfully!\n";
    }

    private static String tellCurrentUsersInfo(){
        String output="";
        User currentUser=Server.getCurrentUser();
        output=output.concat("username: "+currentUser.getUsername()+"\n");
        output=output.concat("password: "+currentUser.getPassword()+"\n");
        output=output.concat("level: "+currentUser.getLevel()+"\n");
        output=output.concat("experience: "+currentUser.getExperience()+"\n");
        output=output.concat("gold: "+currentUser.getGoldAmount()+"\n");
        output=output.concat("rank: "+Server.GetUsersRank(currentUser)+"\n");

        return output;
    }

    private static String removeFromDeck(String cardName){

        if(!isCardNameValid(cardName)) return "Invalid card name!\n";

        BattleCard targetCard=Server.getCurrentUser().getCardFromDeckByName(cardName);
        if(targetCard==null) 
            return "This card isn't in your battle deck!\n";

        if(Server.getCurrentUser().getDeck().size()==1) 
            return "Invalid action: your battle deck will be empty!\n";

        Server.getCurrentUser().getDeck().remove(targetCard);

        return "Card "+cardName+" removed successfully!\n";
    }

    private static String addToDeck(String cardName){

        if(!isCardNameValid(cardName)) return "Invalid card name!\n";

        BattleCard targetCard=Server.getCurrentUser().getUsersOwnedCardByName(cardName);
        if(targetCard==null) return "You don't have this card!\n";

        if(Server.getCurrentUser().getCardFromDeckByName(cardName)!= null)
            return "This card is already in your battle deck!\n";
        
        if(Server.getCurrentUser().getDeck().size()==4)
            return "Invalid action: your battle deck is full!\n";


        Server.getCurrentUser().getDeck().add(targetCard);

        return "Card "+cardName+" added successfully!\n";
    }

    private static String showDeck(){
        User currentUser=Server.getCurrentUser();
        String output="";

        for (int i = 1; i < currentUser.getDeck().size()+1; i++) {
            output=output.concat(currentUser.getDeckCardBylexigographicOrder(i).getCardName()+"\n");
        }

        return output;
    }

    private static void setMenuName(String name){
        MenuName=name;
    }

    private static String getMenuName(){
        return MenuName;
    }
}
