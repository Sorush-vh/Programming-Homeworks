import java.util.ArrayList;
import java.util.Scanner;
import java.util.regex.Matcher;

public class ShopMenu extends Menu {
    
    private static ArrayList<BattleCard> shop;
    private static String MenuName;
    private static boolean keepGoing=true;

    static{
        shop=new ArrayList<BattleCard>();
        ShopMenu.setMenuName("Shop Menu");
        fillShop();
    }

    public static void run(Scanner scanner){

        String buyCardRegex="buy card (?<cardName>.+)";
        String sellCardRegex="sell card (?<cardName>.+)";

        String input,output="";

        while (keepGoing) {
            input=scanner.nextLine();

            Matcher buyCardMatcher=Commands.giveTheMatcherStraightUp(input, buyCardRegex);
            Matcher sellCardMatcher=Commands.giveTheMatcherStraightUp(input, sellCardRegex);

            if(buyCardMatcher.matches()){
                String cardName=buyCardMatcher.group("cardName");
                output=buyCard(cardName);
            }
            else if(sellCardMatcher.matches()){
                String cardName=sellCardMatcher.group("cardName");
                output=sellCard(cardName);
            }
            else if(input.equals(showCurrentMenuFormat)){
                output="Shop Menu\n";
            }
            else if(input.equals("back")){
                output="Entered main menu!\n";
                keepGoing=false;
            }
            else output="Invalid command!\n";

            System.out.print(output);
            output="";
        }
        keepGoing=true;
        MainMenu.run(scanner);
    }

    private static String buyCard( String cardName){

        if(!isCardNameValid(cardName)) return "Invalid card name!\n";

        BattleCard targetCard=getCardByName(cardName);

        if(targetCard.getCost()>Server.getCurrentUser().getGoldAmount())
         return "Not enough gold to buy "+ cardName+ "!\n";

        if(Server.getCurrentUser().getUsersOwnedCardByName(cardName)!=null) return "You have this card!\n";

        Server.getCurrentUser().getAcquiredCards().add(targetCard);
        Server.getCurrentUser().changeGoldAmount(-targetCard.getCost());

        return "Card "+cardName+" bought successfully!\n";
    }

    private static String sellCard(String cardName){

 

        if(!isCardNameValid(cardName)) return "Invalid card name!\n";

        BattleCard targetCard=getCardByName(cardName);

        if(Server.getCurrentUser().getUsersOwnedCardByName(cardName)==null)
             return "You don't have this card!\n";

        if(Server.getCurrentUser().getCardFromDeckByName(cardName)!=null)
             return "You cannot sell a card from your battle deck!\n";


        int addedGold=(8 * targetCard.getCost())/10 ;

        Server.getCurrentUser().changeGoldAmount(addedGold);
        Server.getCurrentUser().RemoveAcquiredCardByName(cardName);

        return "Card "+cardName+" sold successfully!\n";
    }

    private static BattleCard getCardByName(String name){
        for (BattleCard battleCard : shop) {
            if(battleCard.getCardName().equals(name)) return battleCard;
        }
        return null;
    }

    private static void setMenuName(String name){
        MenuName=name;
    }

    private static String getMenuName(){
        return MenuName;
    }

    private static void fillShop(){
        Troops barbarian=Troops.makeBarbarian();
        shop.add(barbarian);

        Troops iceWizard=Troops.makeIceWizard();
        shop.add(iceWizard);
        
        Troops babyDragon=Troops.makeBabyDragon();
        shop.add(babyDragon);

        Spells fireball=Spells.makeFireball();
        shop.add(fireball);

        Spells heal=Spells.makeHealSpell();
        shop.add(heal);
    }

}
