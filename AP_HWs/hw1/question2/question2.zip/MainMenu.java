import java.util.Scanner;
import java.util.regex.Matcher;

public class MainMenu extends Menu {
    //Game Menu
    private static String MenuName;
    private static boolean keepGoing=true;
    private static String nextMenu;
    private static User opponent;
    private static int gameTurnCounter;

    static{
        MainMenu.setMenuName("Main Menu");
    }

    //ToDo: start game

    public static void run(Scanner scanner){
        String input,output="";
        MenuName="";
        nextMenu="";
        opponent=null;
        gameTurnCounter=0;

        String startGameRegex="start game turns count (?<turnsCount>\\d+) username (?<username>.+)";

        while (keepGoing) {
            input=scanner.nextLine();
            Matcher startGameMatcher=Commands.giveTheMatcherStraightUp(input, startGameRegex);

            if(input.equals("list of users")){
                output=showListOfUsers();
            }
            else if(input.equals("scoreboard")){
                output=showScoreboard();
            }
            else if(input.equals(showCurrentMenuFormat)){
                output="Main Menu\n";
            }
            else if(input.equals("profile menu")){
                output="Entered profile menu!\n";
                nextMenu="profile";
                keepGoing=false;
            }
            else if(startGameMatcher.matches()){
                String turn=startGameMatcher.group("turnsCount");
                String opponentz=startGameMatcher.group("username");
                output=startGame(turn, opponentz);
                if(opponent != null){
                nextMenu="game";
                keepGoing=false;
                }
            }
            else if(input.equals("logout")){
                output="User "+Server.getCurrentUser().getUsername()+" logged out successfully!\n";
                Server.setCurrentUser(null);
                nextMenu="register";
                keepGoing=false;
            }
            else if(input.equals("shop menu")){
                output="Entered shop menu!\n";
                nextMenu="shop";
                keepGoing=false;
            }
            else output="Invalid command!\n";

            System.out.print(output);
            output="";
        }
        keepGoing=true;
        runNextMenuAccordingly(scanner);
    }

    private static String startGame(String turnsCount,  String opponentName){
        int turnsInNumber=Integer.parseInt(turnsCount);

        if(turnsInNumber<5 || turnsInNumber>30) return "Invalid turns count!\n";

        if(!isUsernameValid(opponentName)) return "Incorrect format for username!\n";

        if(Server.getUserByUsername(opponentName)==null) return "Username doesn't exist!\n";

        opponent=Server.getUserByUsername(opponentName);

        gameTurnCounter=turnsInNumber;
        return "Battle started with user "+opponentName+"\n";
    }

    private static String showListOfUsers(){
        String output="";
        int index=1;

        //user 1: <username>
        for (User user : Server.getUsers()) {
            output=output.concat("user "+index+": ");
            output=output.concat(user.getUsername());
            output=output.concat("\n");

            index++;
        }

        return output;
    }

    private static String showScoreboard(){
        //<rank>- username: <username> level: <level> experience: <experience>
        String output="";
        User indexUser;
        int validIteration;

        if(Server.getUsers().size()>5) validIteration=5;
        else validIteration=Server.getUsers().size();

        for (int i = 1; i < validIteration+1; i++) {

            indexUser=Server.GetUserByRank(i);
            output=output.concat(""+i+"- ");
            output=output.concat("username: "+indexUser.getUsername()+" ");
            output=output.concat("level: "+indexUser.getLevel()+" ");
            output=output.concat("experience: "+indexUser.getExperience());
            output=output.concat("\n");
        }

        return output;
    }

    private static void setMenuName(String name){
        MenuName=name;
    }

    private static String getMenuName(){
        return MenuName;
    }

    private static void runNextMenuAccordingly(Scanner scanner){

        if(nextMenu.equals("register")){
            Server.setCurrentUser(null);
            RegisterMenu.run(scanner);
        }
        else if(nextMenu.equals("shop")){
            ShopMenu.run(scanner);
        }
        else if(nextMenu.equals("profile")){
            ProfileMenu.run(scanner);
        }
        else if(nextMenu.equals("game")){
            GameMenu.runGame(Server.getCurrentUser(), opponent, scanner, gameTurnCounter);
        }
    }
}
