package org.example;

public enum TopicType {
    TEMPERATURE,
    HUMIDITY,
    BRIGHTNESS,
}
