package org.example;

public enum ClientType {
    PUBLISHER,
    SUBSCRIBER,
    UNKNOWN,
}
