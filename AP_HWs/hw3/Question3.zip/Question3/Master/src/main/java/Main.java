
import java.io.IOException;

import view.Master;

public class Main {
    public static void main(String[] args) throws IOException {
        Master master = new Master(8080);
    }
}